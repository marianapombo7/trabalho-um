fetch('https://api.disneyapi.dev/characters/308').then(resposta => {
    return resposta.json() 
}).then(corpo=>{
    document.getElementById("videogames").innerHTML=corpo.films
    document.getElementById("filmes").innerHTML=corpo.videoGames 
})



const JSON_PATH = 'https://yayinternet.github.io/lecture17/oo-albums/albums.json';
const SORT_YEAR_ASC = function(a, b) {
  return a.year - b.year;
};
const SORT_YEAR_DESC = function(a, b) {
  return b.year - a.year;
};
const SORT_ALPHA_TITLE = function(a, b) {
  const titleA = a.name.toUpperCase();
  const titleB = b.name.toUpperCase();
  if (titleA < titleB) { return -1; }
  if (titleA > titleB) { return 1; }
  return 0;
};

class App {
  constructor() {
    this._onJsonReady = this._onJsonReady.bind(this);
    this._sortAlbums = this._sortAlbums.bind(this);
    
    const ascElement = document.querySelector('#asc');
    const ascButton = new SortButton(
      ascElement, this._sortAlbums, SORT_YEAR_ASC);
    const descElement = document.querySelector('#desc');
    const descButton = new SortButton(
      descElement, this._sortAlbums, SORT_YEAR_DESC);
    const alphaElement = document.querySelector('#alpha');
    const alphaButton = new SortButton(
      alphaElement, this._sortAlbums, SORT_ALPHA_TITLE);
  }
  
  _sortAlbums(sortFunction) {
    this.albumInfo.sort(sortFunction);
    this._renderAlbums();
  }
  
  _renderAlbums() {
    const albumContainer = document.querySelector('#album-container');
    albumContainer.innerHTML = '';
    for (const info of this.albumInfo) {
      const album = new Album(albumContainer, info.url);
    }
  }
  
  loadAlbums() {
    fetch(JSON_PATH)
        .then(this._onResponse)
        .then(this._onJsonReady);
  }

  _onJsonReady(json) {
    this.albumInfo = json.albums;
    this._renderAlbums();
  }

  _onResponse(response) {
    return response.json();
  }
}

class SortButton {
  constructor(containerElement, onClickCallback, sortFunction) {
    this._onClick = this._onClick.bind(this);
    this.onClickCallback = onClickCallback;
    
    this.sortFunction = sortFunction;
    containerElement.addEventListener('click', this._onClick);
  }
  
  _onClick() {
    this.onClickCallback(this.sortFunction);
  }
}

class Album {
  constructor(albumContainer, imageUrl) {
    // Same as document.createElement('img');
    const image = new Image();
    image.src = imageUrl;
    albumContainer.append(image);
  }
}

// script.js
const app = new App();
app.loadAlbums();



function createNode(element) {
    return document.createElement(element);
}

function append(parent, el) {
  return parent.appendChild(el);
}

const ul = document.getElementById('authors');
const url = 'https://api.disneyapi.dev/characters/308';

fetch(url)
.then((resp) => resp.json())
.then(function(data) {
  let authors = data.results;
  return authors.map(function(author) {
    let li = createNode('li');
    let img = createNode('img');
    let span = createNode('span');
    img.src = author.picture.medium;
    span.innerHTML = `${author.name.first} ${author.name.last}`;
    append(li, img);
    append(li, span);
    append(ul, li);
  })
})
.catch(function(error) {
  console.log(error);
});



function onTextReady(text) {
    console.log("as");
    const urls = text.split('\n');
    for (const url of urls) {
      const image2 = new Image();
      image2.src = url;
      document.body.append(image2);
    }
  }
  
  function onResponse(response) {
    console.log("teste");
    return response.text();
  }
  
  fetch('https://api.disneyapi.dev/characters/308')
      .then(onResponse)
      .then(onTextReady);
  
  






  
      